#include <stdio.h>

int main() {
    printf("uitleg over onderstaande tabel\n\n");
    printf("Tabel met alle applicaties in de project folder\n\n\n");
    printf("uitleg over benodigde input van user\n\n");
    while(1);
}